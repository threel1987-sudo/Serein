export const defaultWindowShadows = [];
